%-%----------------------------------------------------------------------%-
%-%--------- Cartesian Planet-Centered Inertial (PCI) Position ----------%-
%-%------- and Cartesian Planet-Centered Inertial (PCI) Velocity --------%-
%-%------------------------ from Orbital Elements -----------------------%-
%-%----------------------------------------------------------------------%-
%-%----------------------------------------------------------------------%-
%-%----------------------------------------------------------------------%-
%-% Input:  orbital elements             (6 by 1 column vector)          %-
%-%   oe(1): Semi-major axis.                                            %-
%-%   oe(2): Eccentricity.                                               %-
%-%   oe(3): Longitude of the ascending node (deg)                       %-
%-%   oe(4): Inclination (deg)                                           %-
%-%   oe(5): Argument of the periapsis (deg)                             %-
%-%   oe(6): True anomaly (deg)                                          %-
%-%   mu:    Planet gravitational parameter     (scalar)                 %-
%-% Outputs:                                                             %-
%-%   r:  Planet-Centered Inertial (PCI) Cartesian position           %-
%-%          (3 by 1 column vector)                                      %-
%-%   v:  Planet-Centered Inertial (PCI) Cartesian inertial velocity  %-
%-%          (3 by 1 column vector)                                      %-
%-%----------------------------------------------------------------------%-
function rv = oe2rv(oe)
% moving orbital elements to variables
mu = 3.986004415e5; %km^2/s^3
a = oe(1);
e = oe(2);
Omega = deg2rad(oe(3));
inc = deg2rad(oe(4));
omega = deg2rad(oe(5));
nu = deg2rad(oe(6));

% solving for r and v in Periapsis-focal basis (PFB)
p = a*(1-e^2);                                    %semi-latus rectum
r = p/(1+e*cos(nu));                              %magnitude of r in PFB
rPFB = [r*cos(nu); r*sin(nu); 0];                 %radius in PFB
vPFB = sqrt(mu/p)*[-sin(nu); e + cos(nu); 0];  %velocity in PFB

%Tanformation from N to I
TNI = [cos(Omega), -sin(Omega), 0; sin(Omega), cos(Omega), 0; 0, 0, 1];
%Transformation from Q to N
TQN = [1, 0, 0; 0, cos(inc), -sin(inc); 0, sin(inc), cos(inc)];
%Transformation from P to Q
TPQ = [cos(omega), -sin(omega), 0; sin(omega), cos(omega), 0; 0, 0, 1];

%solving for final outputs
r = TNI*TQN*TPQ*rPFB;
v = TNI*TQN*TPQ*vPFB;
rv = [r; v];
end
