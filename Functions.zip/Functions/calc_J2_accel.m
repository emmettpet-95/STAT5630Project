function a_J = calc_J2_accel(r)
%%% Function to calculate the accelerations due to J2 and J3 pertubations

    % Extract state variables
    x = r(1);  
    y = r(2); 
    z = r(3);  
    Req = 6378136.3e-3; %km
    mu = 3.986004415e5; %km^2/s^3
    J2 = 1.081874e-3;
    R = Req;

    % Compute radius terms
    r = norm(r);
    r2 = r^2;
    r7 = r^7;
    % z2_r2 = (z^2 / r2);

    % Compute J2 perturbations
    % J2_factor = (3 * mu * J2 * R^2 / (2 * r5));
    % aJ2x = J2_factor * x * (5 * z2_r2 - 1);
    % aJ2y = J2_factor * y * (5 * z2_r2 - 1);
    % aJ2z = J2_factor * z * (5 * z2_r2 - 3);
    J2_factor = (3/2) * J2 * mu * R^2 / r7;
    aJ2x = J2_factor * x * (5 * z^2 - r2);
    aJ2y = J2_factor * y * (5 * z^2 - r2);
    aJ2z = J2_factor * z * (5 * z^2 - 3*r2);
 
    % Compute J3 perturbations
    % J3 = -2.5324e-6;
    % J3_factor = (5/2) * (mu * J3 * R^3 / r7);
    % aJ3x = J3_factor * x * z * (7 * z2_r2 - 3);
    % aJ3y = J3_factor * y * z * (7 * z2_r2 - 3);
    % aJ3z = J3_factor * (3/5 - 6 * z2_r2 + 7 * z2_r2^2);
    aJ3x = 0; aJ3y = 0; aJ3z = 0;

    % Compute total accelerations
    ax = aJ2x + aJ3x;
    ay = aJ2y + aJ3y;
    az = aJ2z + aJ3z;

    % Construct derivative of state vector
    a_J = [ax; ay; az];
    
end    