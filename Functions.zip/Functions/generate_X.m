function [X, rho, r_lla] = generate_X(tspan, X0, dt_0, HASDM_Grid, time_out, C_D, F)
    
    % ODE options (relaxed slightly for performance)
    options = odeset('RelTol',1e-12,'AbsTol',1e-12);
    
    % Precompute numeric time
    time_num = datenum(time_out);
    
    % Initialize
    N = length(tspan);
    rho = nan(1,N);
    r_lla = nan(3,N);
    
    % Propagate X
    [~, X_sol] = ode45(@(t,X) keplerJ2drag_ODE(t, X, dt_0, HASDM_Grid, time_num, C_D, F), tspan, X0, options);
    X = X_sol.';
    
    % Pull rho and lla (no ODE45)
    for k = 1:N
    
        t = tspan(k);
        Xk = X(:,k);
        [rho(k), r_lla(:,k)] = compute_rho_lla(t, Xk, dt_0, HASDM_Grid, time_num, F);
    
    end

end



