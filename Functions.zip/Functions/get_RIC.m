function RIC_error = get_RIC(X, Xref)
% Xref = reference, no drag or mean density

    N = size(X,2);
    RIC_error = zeros(3,N);

    for k = 1:N
        R_ECI2RIC = rotateECI2RIC(Xref(1:3,k), Xref(4:6,k));
        Xref_ric = R_ECI2RIC*Xref(1:3,k);
        X_ric = R_ECI2RIC*X(1:3,k);
        RIC_error(:,k) = (X_ric - Xref_ric)*1000; %km to m
    end

end

% function RIC_error = get_RIC(X, Xref)
% % Xref = reference trajectory
% 
%     N = size(X,2);
%     RIC_error = zeros(3,N);
% 
%     for k = 1:N
%         r_ref = Xref(1:3,k);
%         v_ref = Xref(4:6,k);
% 
%         R_ECI2RIC = rotateECI2RIC(r_ref, v_ref);
% 
%         % Relative position in ECI
%         dr = X(1:3,k) - r_ref;
% 
%         % Convert to RIC
%         RIC_error(:,k) = R_ECI2RIC * dr * 1000; % km → m
%     end
% 
% end