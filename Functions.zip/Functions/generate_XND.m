% This function uses ode45 to generate an orbit
function Xout = generate_XND(tspan, X0)
   
   options = odeset('RelTol',1e-13,'AbsTol',1e-13);  
   [~, Xout] = ode45( @(t,X) keplerJ2_ODE(t,X), tspan, X0, options);
   Xout = Xout';  

end