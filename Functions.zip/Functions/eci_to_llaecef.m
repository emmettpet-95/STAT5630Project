function [r_lla, r_ecef] = eci_to_llaecef(r_eci, jd)
% Converts ECI [km] to LLA [deg, deg, km] and ECEF [km]
% Inputs:
%   r_eci - [3x1] km
%   jd    - Julian date
% Outputs:
%   r_lla - [lat, lon, alt] in [deg, deg, km]
%   r_ecef - [x,y,z] in km

theta = gmst(jd); % rad

% ECI → ECEF rotation
ECI2ECEF = [ cos(theta),  sin(theta), 0;
            -sin(theta),  cos(theta), 0;
             0,           0,          1];

r_eci = reshape(r_eci, [3,1]);
r_ecef = ECI2ECEF*r_eci;

% Convert ECEF to LLA
lla = ecef2lla(r_ecef); % [rad, rad, km]
r_lla(1) = rad2deg(lla(1)); % lat
r_lla(2) = rad2deg(lla(2)); % lon
r_lla(3) = lla(3);           % alt (km)
r_lla = r_lla';

end

function [lla] = ecef2lla(ecef)

    x = ecef(1);
    y = ecef(2);
    z = ecef(3);
    
    % WGS84 ellipsoid constants:
    a = 6378.137;
    e = 8.1819190842622e-2;
    
    % calculations:
    b   = sqrt(a^2*(1-e^2));
    ep  = sqrt((a^2-b^2)/b^2);
    p   = sqrt(x.^2+y.^2);
    th  = atan2(a*z,b*p);
    lon = atan2(y,x);
    lat = atan2((z+ep^2.*b.*sin(th).^3),(p-e^2.*a.*cos(th).^3));
    N   = a./sqrt(1-e^2.*sin(lat).^2);
    alt = p./cos(lat)-N;
    
    % return lon in range [0,2*pi)
    lon = mod(lon,2*pi);
    
    k=abs(x)<1 & abs(y)<1;
    alt(k) = abs(z(k))-b;
    
    lla = [lat; lon; alt];

end

function theta = gmst(jd)
% GMST Compute Greenwich Mean Sidereal Time (radians) from Julian Date
%
% jd - Julian Date (scalar or array)
% theta - GMST in radians, range [0, 2*pi)

% Julian centuries since J2000.0
T = (jd - 2451545.0)/36525;

% GMST in seconds
GMST_sec = 67310.54841 + (876600*3600 + 8640184.812866)*T + 0.093104*T.^2 - 6.2e-6*T.^3;

% Convert seconds to degrees
GMST_deg = mod(GMST_sec/240, 360);  % 360 deg / 86400 s = 1/240 deg/s

% Convert degrees to radians
theta = deg2rad(GMST_deg);

% Wrap to [0, 2*pi)
theta = mod(theta, 2*pi);

end