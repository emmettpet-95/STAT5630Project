function [a_drag] = calc_drag_accel(r, v, rho, C_D)
%{
 Calculates the drag acceleration acting upon the satellite and
    determines the corresponding density (rho) at that position

    All vectors are in ECI
    r, v - in km or km/s
%}
% Constants
we = 7.2921158553e-5; %rad/s
% C_D = 2.2;
AtoM = 1.94*0.72/600;

% Relative Velocity 
v_rel = v - cross(we*[0; 0; 1], r);
v_rel_m = (1e3)*v_rel; % m/s

% Drag
a_drag_m = (-1/2)*rho*(C_D*AtoM)*norm(v_rel_m)*v_rel_m; %m/s^2
% Convert back to km
a_drag = (1e-3)*a_drag_m; %km/s^2

end