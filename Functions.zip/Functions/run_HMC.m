function [samples, accept_rate] = run_HMC(Phi, y, tau, n_iter, step_size, n_steps)

    beta = zeros(6,1);
    samples = zeros(6,n_iter);
    accept = 0;
    
    for i = 1:n_iter
    
        beta0 = beta;
        p = randn(size(beta));
    
        [logp_old, grad_old] = log_posterior_grad(beta, Phi, y, tau);
        H_old = -logp_old + 0.5*(p'*p);
    
        % Leapfrog
        beta_new = beta;
        p_new = p + 0.5*step_size*grad_old;
    
        for j = 1:n_steps
            beta_new = beta_new + step_size*p_new;
    
            [logp_new, grad_new] = log_posterior_grad(beta_new, Phi, y, tau);
    
            if j ~= n_steps
                p_new = p_new + step_size*grad_new;
            end
        end
    
        p_new = p_new + 0.5*step_size*grad_new;
        p_new = -p_new;
    
        H_new = -logp_new + 0.5*(p_new'*p_new);
    
        if isfinite(H_new) && log(rand) < (H_old - H_new)
            beta = beta_new;
            accept = accept + 1;
        end
    
        samples(:,i) = beta;
    
    end

    accept_rate = accept / n_iter;
    disp(accept_rate)

end