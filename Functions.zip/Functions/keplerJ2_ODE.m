function dXdt = keplerJ2_ODE(t, X)
% ODE Function including mu, J2 of Earth

% Constants
% Req = 6378136.3e-3; %km
mu = 3.986004415e5; %km^2/s^3
% J2 = 1.081874e-3;

% Unpack X
r = X(1:3); % position in ECI, km
v = X(4:6); % velocity in ECI, km/s

% Compute Derivatives
rd = v;
a_J2 = calc_J2_accel(r);

vd = (-mu/norm(r)^3)*r + a_J2;

% Output
dXdt = [rd; vd];

end