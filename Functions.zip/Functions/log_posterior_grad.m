function [logp, grad] = log_posterior_grad(beta, Phi, y, tau)

    N = length(y);
    r = y - Phi*beta;

    % Likelihood
    logL = -0.5*(r'*r)/(tau^2) - N*log(tau);
    gradL = (Phi' * r) / (tau^2);

    % Priors
    logP = 0;
    gradP = zeros(6,1);

    % b0 ~ N(0,16)
    logP = logP - 0.5*(beta(1)/16)^2;
    gradP(1) = -beta(1)/16^2;

    % b1 ~ Uniform(-5,5)
    if abs(beta(2)) > 5
        logp = -Inf;
        grad = zeros(6,1);
        return;
    end

    % b2 ~ N(0.5,1)
    logP = logP - 0.5*(beta(3)-0.5)^2;
    gradP(3) = -(beta(3)-0.5);

    % b3 ~ N(-1,1)
    logP = logP - 0.5*(beta(4)+1)^2;
    gradP(4) = -(beta(4)+1);

    % b4 ~ N(1,1)
    logP = logP - 0.5*(beta(5)-1)^2;
    gradP(5) = -(beta(5)-1);

    % b5 ~ N(1,1)
    logP = logP - 0.5*(beta(6)-1)^2;
    gradP(6) = -(beta(6)-1);

    % Combine
    logp = logL + logP;
    grad = gradL + gradP;

end