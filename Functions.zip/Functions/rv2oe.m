%-%----------------------------------------------------------------------%-
%-%------------ Code Template for Computing Orbital Elements ------------%-
%-%----------- from Cartesian Planet-Centered Inertial (PCI) ------------%-
%-%-------- and Cartesian Planet-Centered Inertial (PCI) Velocity -------%-
%-%----------------------------------------------------------------------%-
%-%----------------------------------------------------------------------%-
%-%----------------------------------------------------------------------%-
% Inputs:                                                                %-
%    r:  Cartesian planet-centered inertial (PCI) position (3 by 1)   %-
%    v:  Cartesian planet-centered inertial (PCI) velocity (3 by 1)   %-
%    mu:    gravitational parameter of centrally attacting body.         %-
% Outputs:  orbital elements                                             %-
%    oe(1): semi-major axis.                                             %-
%    oe(2): eccentricity.                                                %-
%    oe(3): longitude of the ascending node (deg)                        %-
%    oe(4): inclination (deg)                                            %-
%    oe(5): argument of the periapsis (deg)                              %-
%    oe(6): true anomaly (deg)                                           %-
%-%----------------------------------------------------------------------%-
function oe = rv2oe(r,v)
    mu = 3.986004415e5; %km^2/s^3

    % calculations
    h = cross(r,v);                           %specific angular momentum
    p = (norm(h)^2)/mu;                         %semi-latus rectum
    ev = (cross(v,h)/mu) - r/norm(r);       %eccentricity vector
    e = norm(ev);                               %eccentricity
    a = p/(1-e^2);                              %semi-major axis
    
    % True anomaly calculation, nu
    nu = atan2(-dot(r, cross(h,ev)), -dot(r,ev)*norm(h)) + pi;
    %atan2() + pi is the four-quadrant inverse tangent that transforms the
    %range from [-pi,pi] to [0,2pi]
    
    % Longitude of the ascending node calculation, Omega
    Ix = [1; 0; 0];
    Iy = [0; 1; 0];
    Iz = [0; 0; 1];
    n = cross(Iz, h); %line of nodes
    Omega = atan2(-1*dot(Iy,n), -dot(Ix,n)) + pi;
    
    % Inclination, inc
    b = [dot(Ix,h); dot(Iy,h); 0];
    inc = atan2(dot(h,b), norm(b)*dot(h,Iz));
    
    % Argument of the Periapsis, omega
    omega = atan2(-dot(ev,cross(h,n)), -norm(h)*dot(ev,n)) + pi;
    
    % orbital elements
    Omega = rad2deg(Omega); inc = rad2deg(inc); omega = rad2deg(omega); nu = rad2deg(nu);
    oe = [a; e; Omega; inc; omega; nu];
end
