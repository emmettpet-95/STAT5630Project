function rho = find_rho(lat_q, lon_q, alt_q, tq_num, HASDM_Grid, time_num, F)
    Rho_out = HASDM_Grid.rho; 
    LatGrid = HASDM_Grid.lat; 
    LonGrid = HASDM_Grid.lon; 
    AltGrid = HASDM_Grid.alt; 
    % time_out = HASDM_Grid.time;
    % Find nearest index 
    % Latitude 
    lat_vec = LatGrid(:,1,1); 
    [~, i_lat] = min(abs(lat_vec - lat_q)); %
    % Longitude
    lon_vec = LonGrid(1,:,1); 
    [~, i_lon] = min(abs(lon_vec - lon_q)); 
    % Altitude 
    alt_vec = squeeze(AltGrid(1,1,:)); 
    [~, i_alt] = min(abs(alt_vec - alt_q)); 
    % Time 
    [~, i_time] = min(abs(time_num - tq_num)); 
    % Nearest value 
    rho = Rho_out(i_lat, i_lon, i_alt, i_time); 
end
%     % Longitude wrap
%     if lon_q < 0
%         lon_q = lon_q + 360;
%     end
% 
%     % --- Time indices ---
%     if tq_num <= time_num(1)
%         t1 = 1; t2 = 1;
%     elseif tq_num >= time_num(end)
%         t1 = length(time_num); t2 = t1;
%     else
%         t2 = find(time_num >= tq_num, 1);
%         t1 = t2 - 1;
%     end
% 
%     % Time interpolation weight
%     if t1 == t2
%         alpha = 0;
%     else
%         alpha = (tq_num - time_num(t1)) / (time_num(t2) - time_num(t1));
%     end
% 
%     % --- Evaluate interpolants (FAST) ---
%     logRho_q1 = F{t1}(lat_q, lon_q, alt_q);
%     logRho_q2 = F{t2}(lat_q, lon_q, alt_q);
% 
%     % Time interpolation
%     logRho_q = (1 - alpha)*logRho_q1 + alpha*logRho_q2;
% 
%     rho = exp(logRho_q);
% 
% end