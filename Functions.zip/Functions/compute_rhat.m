function Rhat = compute_rhat(chains)

% chains: [P x N x C]
[P, N, C] = size(chains);

Rhat = zeros(P,1);

for p = 1:P

    X = squeeze(chains(p,:,:));   % [N x C]

    % Chain means
    chain_means = mean(X,1);

    % Overall mean
    grand_mean = mean(chain_means);

    % Between-chain variance
    B = N * var(chain_means, 1);

    % Within-chain variance
    W = mean(var(X, 0, 1));

    % Variance estimate
    Var_hat = ((N-1)/N)*W + (1/N)*B;

    % R-hat
    Rhat(p) = sqrt(Var_hat / W);

end

end