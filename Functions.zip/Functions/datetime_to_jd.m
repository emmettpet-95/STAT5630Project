function jd = datetime_to_jd(t)
% DATETIME_TO_JD Convert MATLAB datetime to Julian Date
% Input:
%   t - MATLAB datetime (scalar or array)
% Output:
%   jd - Julian Date (same size as t)

% Ensure t is datetime
if ~isa(t, 'datetime')
    error('Input must be a datetime array.');
end

% Extract components
Y = year(t);
M = month(t);
D = day(t);
H = hour(t);
Min = minute(t);
S = second(t);

% Convert to Julian Day
% Formula from Meeus, Astronomical Algorithms
I = Y;
J = M;
if J <= 2
    I = I - 1;
    J = J + 12;
end

A = floor(I / 100);
B = 2 - A + floor(A / 4);

JD_day = floor(365.25*(I+4716)) + floor(30.6001*(J+1)) + D + B - 1524.5;

% Add fraction of the day
JD_frac = (H + Min/60 + S/3600)/24;

jd = JD_day + JD_frac;

end