function [dXdt] = keplerJ2drag_ODE(t, X, dt_0, HASDM_Grid, time_num, C_D, F)

datetime_t = dt_0 + seconds(t);
tq_num = time_num(1) + t/86400;
jd = datetime_to_jd(datetime_t);

% Unpack X
r = X(1:3); %[km]
v = X(4:6); %[km]

% Get gravity accel
va_G = keplerJ2_ODE(t, X);
a_G = va_G(4:6);

% Find rho
[r_lla, ~] = eci_to_llaecef(r, jd); % [lat, lon, alt]
lat_q = r_lla(1);
lon_q = r_lla(2);
alt_q = r_lla(3);

rho = find_rho(lat_q, lon_q, alt_q, tq_num, HASDM_Grid, time_num, F);

% Derivatives 
rd = v;
a_drag = calc_drag_accel(r, v, rho, C_D);
vd = a_G + a_drag;

% Output
dXdt = [rd; vd];

end
