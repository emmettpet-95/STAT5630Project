function R_ECI2RIC = rotateECI2RIC(r,v)
%{
Outputs rotation matrix to rotate from the ECI frame to the RIC frame. 
RIC Frame:
    (1) - R = radial out, radial
    (2) - I = -R x C, roughly in velocity direction, in-track
    (3) - C = orbit plane angular momentum, cross-track

Inputs:
    r - [3x1] position vector
    v - [3x1] velocity vector

%}

R_hat = r/norm(r,2);
C_hat = cross(r, v)/norm(cross(r, v),2);
I_hat = cross(C_hat, R_hat);

R_ECI2RIC = [R_hat.'; I_hat.'; C_hat.'];

end 