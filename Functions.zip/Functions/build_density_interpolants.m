function F_time = build_density_interpolants(HASDM_Grid)

    Rho_out  = HASDM_Grid.rho;
    LatGrid  = HASDM_Grid.lat;
    LonGrid  = HASDM_Grid.lon;
    AltGrid  = HASDM_Grid.alt;

    lat_vec = LatGrid(:,1,1);
    lon_vec = LonGrid(1,:,1);
    alt_vec = squeeze(AltGrid(1,1,:));

    Nt = size(Rho_out, 4);
    F_time = cell(Nt,1);

    for t = 1:Nt
        logRho = log(squeeze(Rho_out(:,:,:,t)));

        F_time{t} = griddedInterpolant( ...
            {lat_vec, lon_vec, alt_vec}, ...
            logRho, ...
            'linear', 'nearest');
    end

end