function plot_density_violin(saved_data_quiet, saved_data_storm)

rho_quiet = saved_data_quiet.rho;  
rho_storm = saved_data_storm.rho;  
w_quiet_all = saved_data_quiet.w;
w_storm_all = saved_data_storm.w;
tspan = saved_data_quiet.tspan;

% Find full hours
full_hour_idx = minute(tspan) == 0;
hour_times_all = tspan(full_hour_idx);

% Keep only every 2 hours (0,2,4,...)
hour_vals_all = hour(hour_times_all);                 % numeric hour 0-23
two_hour_idx = mod(hour_vals_all,1) == 0;            
hour_times = hour_times_all(two_hour_idx);
hour_vals = hour(hour_times);                         % numeric hours
num_hours = length(hour_times);
num_values = size(rho_quiet,2);

% Preallocate matrices
hourly_quiet = nan(num_values, num_hours);
hourly_storm = nan(num_values, num_hours);
weights_quiet = nan(num_values, num_hours);
weights_storm = nan(num_values, num_hours);

for i = 1:num_hours
    idx = tspan == hour_times(i);      % select this hour
    hourly_quiet(:,i) = rho_quiet(idx,:)';  
    hourly_storm(:,i) = rho_storm(idx,:)';  
    weights_quiet(:,i) = w_quiet_all(:,idx);  
    weights_storm(:,i) = w_storm_all(:,idx);  
end

% Determine global y-axis limits
ymin = min([hourly_quiet(:); hourly_storm(:)]);
ymax = max([hourly_quiet(:); hourly_storm(:)]);

% X-axis positions and labels
% tick_idx = 1:num_hours;
% tick_labels = string(hour_vals);
tick_idx = 1:num_hours;                    % positions for violin plots
tick_labels = string(round(saved_data_quiet.t_hr(full_hour_idx)));  % elapsed hours

% ADD ALL LINES
E = size(saved_data_quiet.rho,2);
w_max_quiet = max(saved_data_quiet.w(:,:));
w_min_quiet = min(saved_data_quiet.w(:,:));
w_max_storm = max(saved_data_storm.w(:,:));
w_min_storm = min(saved_data_storm.w(:,:));

% Quiet ensemble (weights are in rows)
figure;
subplot(2,1,1)
for e = 1:E
    y = saved_data_quiet.rho(:,e);
    w = saved_data_quiet.w(e,:)';   % Nt×1
    plot_weighted_lines(saved_data_quiet.t_hr + 1, y, w, w_min_quiet, w_max_quiet);
end
% --- Custom colormap: light blue -> deep blue ---
cmap = [linspace(0.85,0,64)', linspace(0.95,0,64)', linspace(1,0.5,64)'];
colormap(cmap);
caxis([0 1]);
% --- Add colorbar
cb = colorbar('eastoutside');    % on right
cb.Label.String = 'Normalized Weight';
cb.Label.Color = [0 0 0];       % white label for dark background
cb.Color = [0 0 0];             % white tick labels
cb.AxisLocation = 'out';         % outside axes


% --- Quiet subplot ---
subplot(2,1,1);
hold on
% plot(tick_idx, hourly_quiet,'Color', [0.6 0.8 1.0], 'LineWidth', 0.5);   
violin(hourly_quiet, 'facecolor', [0.8500 0.3250 0.0980], 'weights', weights_quiet);
ylim([ymin ymax]);
ax = gca;
ax.XTick = tick_idx;
ax.XTickLabel = tick_labels;
% xtickangle(45);

% Dark gray background
set(gcf,'Color',[1 1 1]); % figure background
ax.Color = [0.5 0.5 0.5];          % axes background
% White text
% ax.XColor = [1 1 1];
% ax.YColor = [1 1 1];
ax.GridColor = [0 0 0];
ax.GridAlpha = 0.3;
grid on;
xlabel('Elapsed Time [hr]','Color',[0 0 0]);
ylabel('Density [kg/m^3]','Color',[0 0 0]);
title('a) Quiet','Color',[0 0 0]);

% --- Storm subplot ---
subplot(2,1,2)
for e = 1:E
    y = saved_data_storm.rho(:,e);
    w = saved_data_storm.w(e,:)';   % Nt×1
    plot_weighted_lines(saved_data_storm.t_hr + 1, y, w, w_min_storm, w_max_storm);
end
% --- Custom colormap: light blue -> deep blue ---
cmap = [linspace(0.85,0,64)', linspace(0.95,0,64)', linspace(1,0.5,64)'];
colormap(cmap);
caxis([0 1]);
% --- Add colorbar
cb = colorbar('eastoutside');    % on right
cb.Label.String = 'Normalized Weight';
cb.Label.Color = [0 0 0];       % white label for dark background
cb.Color = [0 0 0];             % white tick labels
cb.AxisLocation = 'out';         % outside axes

subplot(2,1,2);
hold on
% plot(tick_idx, hourly_storm,'Color', [1.0 0.7 0.7], 'LineWidth', 0.5);  
violin(hourly_storm, 'facecolor', [0.8500 0.3250 0.0980], 'weights', weights_storm);
ylim([ymin ymax]);
ax = gca;
ax.XTick = tick_idx;
ax.XTickLabel = tick_labels;
% xtickangle(45);

% Dark gray background
% set(gcf,'Color',[0.15 0.15 0.15]); % figure background
ax.Color = [0.5 0.5 0.5];          % axes background
% White text
% ax.XColor = [1 1 1];
% ax.YColor = [1 1 1];
ax.GridColor = [0 0 0];
ax.GridAlpha = 0.3;
grid on;
xlabel('Elapsed Time [hr]','Color',[0 0 0]);
ylabel('Density [kg/m^3]','Color',[0 0 0]);
title('b) Storm','Color',[0 0 0]);

sgtitle('Quiet and Storm Period Density and Distributions','color',[0,0,0])

end
