function plot_intrack_stats2(Run)

tspan = Run.tspan;
% Istats = Run.Istats;
Istats = Run.Istats2;
mu = Istats.mu;
sd = Istats.sd;
skew = Istats.skew;
kurt = Istats.kurt;

figure()
t = tiledlayout(4,1,'TileSpacing','tight','Padding','compact'); % no vertical gaps

txt = {'Standard Deviation [km]','Skewness','Kurtosis','Mean [km]'};

% ---- 1st plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(tspan, mu, 'b.')
hold on
ylabel(txt{4})
xticklabels([]) % no x labels here
grid on
% ylim([0 10])
% text(0.5, 8.8, 'a)', 'FontSize', 16, 'Color', 'r')

% ---- 2nd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(tspan, sd, 'b.')
hold on
ylabel(txt{1})
xticklabels([]) % no x labels here
grid on
% ylim([0 1.2])
% text(0.5, 1.05, 'b)', 'FontSize', 16, 'Color', 'r')

% ---- 3rd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(tspan, skew, 'b.')
hold on
ylabel(txt{2})
xticklabels([])
grid on
% ylim([-1 1])
% text(0.5, 0.75, 'c)', 'FontSize', 16, 'Color', 'r')

% ---- 4th plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(tspan, kurt, 'b.')
hold on
ylabel(txt{3})
xlabel('Elapsed Time')
grid on
% ylim([1 4])
% text(0.5, 3.7, 'd)', 'FontSize', 16, 'Color', 'r')

% Format time axis every hour
% xticks(0:1:36)

% Title + background
sgtitle('Storm Period In-Track Position Difference Statistics')
set(gcf,'Color',[1 1 1]);

end