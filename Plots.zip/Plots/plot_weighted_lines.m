function plot_weighted_lines(t, y, w, w_min, w_max)
    t = t(:);
    y = y(:);
    w = w(:);

    Nt = length(t);
    if length(w) ~= Nt
        error('Length mismatch: t=%d, y=%d, w=%d', length(t), length(y), length(w));
    end

    % Normalize weights 0-1
    w_norm = w ./ max(w);

    % Surface plot with scalar coloring
    X = [t'; t'];
    Y = [y'; y'];
    Z = zeros(2,Nt);
    Csurf = [w_norm'; w_norm'];

    surface(X, Y, Z, Csurf, ...
        'EdgeColor','interp', ...
        'FaceColor','none', ...
        'LineWidth',1, ...
        'HandleVisibility','off');
    % 
    % % --- Custom colormap: light blue -> deep blue ---
    % cmap = [linspace(0.85,0,64)', linspace(0.95,0,64)', linspace(1,0.5,64)'];
    % colormap(cmap);
    % caxis([0 1]);
    % 
    % % --- Add colorbar only once ---
    % if isempty(findobj(gcf,'Type','ColorBar'))
    %     cb = colorbar('eastoutside');    % on right
    %     cb.Label.String = 'Normalized Weight';
    %     cb.Label.Color = [1 1 1];       % white label for dark background
    %     cb.Color = [1 1 1];             % white tick labels
    %     cb.AxisLocation = 'out';         % outside axes
    % end
end
