function plot_intrack_stats3()

    load('Run1.mat'); load('Run2.mat');
    load('Run3.mat'); load('Run4.mat');

    tspan = Run1.tspan / 3600;

    Istats = {Run1.Istats2, Run2.Istats2, Run3.Istats2, Run4.Istats2};

    figure()
    tiledlayout(4,1,'TileSpacing','tight','Padding','compact');

    labels = {'Mean [km]','Coefficent of Variation','Skewness','Kurtosis'};
    colors = {'g','b','r','m'};

    % --- Mean ---
    nexttile; hold on; grid on
    for i = 1:4
        plot(tspan, Istats{i}.mu, colors{i}, 'LineWidth',1.2)
    end

    % Legend (only once)
    legend({'Normal Small Variance','Normal Large Variance','Skewed','Heavy-Tailed'}, ...
           'Location','best')
    ylabel(labels{1})
    xticklabels([])

    % --- Std ---
    nexttile; hold on; grid on
    for i = 1:4
        plot(tspan, Istats{i}.sd ./ Istats{i}.mu, colors{i}, 'LineWidth',1.2)
    end
    ylabel(labels{2})
    xticklabels([])

    % --- Skew ---
    nexttile; hold on; grid on
    for i = 1:4
        plot(tspan, Istats{i}.skew, colors{i}, 'LineWidth',1.2)
    end
    ylabel(labels{3})
    xticklabels([])

    % --- Kurtosis ---
    nexttile; hold on; grid on
    for i = 1:4
        plot(tspan, Istats{i}.kurt, colors{i}, 'LineWidth',1.2)
    end
    ylabel(labels{4})
    xlabel('Time [hr]')

    sgtitle('Orbit Error Statistical Moments Over Time')
    set(gcf,'Color',[1 1 1]);

end