function plotLLA(time, r_lla)
% PLOTLLA Plots Latitude, Longitude, and Altitude over time
%
% Inputs:
%   time  - datetime vector [Nx1]
%   r_lla - 3xN matrix [lat(deg), lon(deg), alt(km)]

% Input validation
if size(r_lla,1) ~= 3
    error('r_lla must be Nx3: [lat, lon, alt]');
end
if length(time) ~= size(r_lla,2)
    error('time and r_lla must have the same number of rows');
end

lat = r_lla(1,:);
lon = r_lla(2,:);
alt = r_lla(3,:);
time = time/3600;

% Plot
figure;

subplot(3,1,1)
plot(time, lat, 'b', 'LineWidth', 1.5)
ylabel('Latitude [deg]')
grid on

subplot(3,1,2)
plot(time, lon, 'r', 'LineWidth', 1.5)
ylabel('Longitude [deg]')
grid on

subplot(3,1,3)
plot(time, alt, 'k', 'LineWidth', 1.5)
ylabel('Altitude [km]')
xlabel('Time [hr]')
grid on

sgtitle('Satellite LLA vs Time')

end