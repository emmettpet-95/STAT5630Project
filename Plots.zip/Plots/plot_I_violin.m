function plot_I_violin(saved_data_quiet, saved_data_storm)

tspan = saved_data_quiet.tspan;
E = size(saved_data_quiet.RIC_error,3);
w_max_quiet = max(saved_data_quiet.w_inter(:,:));
w_min_quiet = min(saved_data_quiet.w_inter(:,:));
w_max_storm = max(saved_data_storm.w_inter(:,:));
w_min_storm = min(saved_data_storm.w_inter(:,:));

% Find full hours
full_hour_idx = minute(tspan) == 0;
hour_times_all = tspan(full_hour_idx);

% Keep only every 2 hours (0,2,4,...)
hour_vals_all = hour(hour_times_all);                 % numeric hour 0-23
two_hour_idx = mod(hour_vals_all,1) == 0;            % indices of hours divisible by 2
hour_times = hour_times_all(two_hour_idx);
hour_vals = hour(hour_times);                         % numeric hours
num_hours = length(hour_times);

% Determine number of values per hour from RIC_error
num_values = size(saved_data_quiet.RIC_error,3);

% Preallocate matrices
hourly_quiet = nan(num_values, num_hours);
hourly_storm = nan(num_values, num_hours);
weights_quiet = nan(num_values, num_hours);
weights_storm = nan(num_values, num_hours);

% Tolerance for datetime matching
tol = minutes(1);

for i = 1:num_hours
    idx = abs(tspan - hour_times(i)) < tol;  % safe comparison

    % Extract 2nd component of RIC_error (Intrack) and convert to km
    tmp_quiet = squeeze(saved_data_quiet.RIC_error(2, idx, :) ./ 1000);  % 100x1
    tmp_storm = squeeze(saved_data_storm.RIC_error(2, idx, :) ./ 1000);  % 100x1
    
    % Only assign if non-empty
    if ~isempty(tmp_quiet)
        hourly_quiet(:, i) = tmp_quiet;           % assign directly, no transpose
        weights_quiet(:, i) = saved_data_quiet.w_inter(:, idx);
    end
    if ~isempty(tmp_storm)
        hourly_storm(:, i) = tmp_storm;
        weights_storm(:, i) = saved_data_storm.w_inter(:, idx);
    end

end

% Set first hour to zeros if desired
hourly_quiet(:,1) = zeros(size(hourly_quiet(:,1)));
hourly_quiet(1,1) = 1e-8;
hourly_storm(:,1) = zeros(size(hourly_storm(:,1)));
hourly_storm(1,1) = 1e-8;

% Determine global y-axis limits
ymin = min([hourly_quiet(:); hourly_storm(:)], [], 'omitnan') - 1;
ymax = max([hourly_quiet(:); hourly_storm(:)], [], 'omitnan');

% % X-axis positions and labels
% tick_idx = 1:num_hours;
% tick_labels = string(hour_vals);
% Use elapsed hours from t_hr
tick_idx = 1:num_hours;                    % positions for violin plots
tick_labels = string(round(saved_data_quiet.t_hr(full_hour_idx)));  % elapsed hours


% --- Quiet subplot ---
figure;
subplot(2,1,1)
hold on 
for e = 1:E
    y = squeeze(saved_data_quiet.RIC_error(2,:,e))./1000;
    w = saved_data_quiet.w_inter(e,:)';   % Nt×1
    plot_weighted_lines(saved_data_quiet.t_hr + 1, y, w, w_min_quiet, w_max_quiet);
end
cmap = [linspace(0.85,0,64)', linspace(0.95,0,64)', linspace(1,0.5,64)'];
colormap(cmap);
caxis([0 1]);
cb = colorbar('eastoutside');    % on right
cb.Label.String = 'Normalized Weight';
cb.Label.Color = [0 0 0];       % white label for dark background
cb.Color = [0 0 0];             % white tick labels
cb.AxisLocation = 'out';         % outside axes
subplot(2,1,1);
hold on
% plot(tick_idx, hourly_quiet,'Color', [0.6 0.8 1.0], 'LineWidth', 0.5);   
violin(hourly_quiet, 'facecolor', [0.8500 0.3250 0.0980], 'weights', weights_quiet);
% ylim([0 ymax]);
ax = gca;
ax.XTick = tick_idx;
ax.XTickLabel = tick_labels;
% xtickangle(45);
% Dark gray background
set(gcf,'Color',[1 1 1]); % figure background
ax.Color = [0.5 0.5 0.5];          % axes background
% White text
% ax.XColor = [1 1 1];
% ax.YColor = [1 1 1];
ax.GridColor = [0 0 0];
ax.GridAlpha = 0.3;
grid on;
xlabel('Elapsed Time [hr]','Color',[0 0 0]);
ylabel('In-Track Position Difference [km]','Color',[0 0 0]);
title('a) Quiet','Color',[0 0 0]);
legend('Location','southeast')
% xlim([1 14])
% ylim([0 1])

% --- Storm subplot ---
subplot(2,1,2)
hold on 
for e = 1:E
    y = squeeze(saved_data_storm.RIC_error(2,:,e))./1000;
    w = saved_data_storm.w_inter(e,:)';   % Nt×1
    plot_weighted_lines(saved_data_storm.t_hr + 1, y, w, w_min_storm, w_max_storm);
end
cmap = [linspace(0.85,0,64)', linspace(0.95,0,64)', linspace(1,0.5,64)'];
colormap(cmap);
caxis([0 1]);
cb = colorbar('eastoutside');    % on right
cb.Label.String = 'Normalized Weight';
cb.Label.Color = [0 0 0];       % white label for dark background
cb.Color = [0 0 0];             % white tick labels
cb.AxisLocation = 'out';         % outside axes
subplot(2,1,2);
hold on
% plot(tick_idx, hourly_storm,'Color', [1.0 0.7 0.7], 'LineWidth', 0.5);   
violin(hourly_storm, 'facecolor', [0.8500 0.3250 0.0980], 'weights', weights_storm);
ylim([0 ymax]);
ax = gca;
ax.XTick = tick_idx;
ax.XTickLabel = tick_labels;
% xtickangle(45);
% Dark gray background
% set(gcf,'Color',[0.15 0.15 0.15]); % figure background
ax.Color = [0.5 0.5 0.5];          % axes background
% White text
% ax.XColor = [1 1 1];
% ax.YColor = [1 1 1];
ax.GridColor = [0 0 0];
ax.GridAlpha = 0.3;
grid on;
xlabel('Elapsed Time [hr]','Color',[0 0 0]);
ylabel('In-Track Position Difference [km]','Color',[0 0 0]);
title('b) Storm','Color',[0 0 0]);
legend('Location','southeast')
% xlim([1 14])
% ylim([0 2.2])

sgtitle('Quiet and Storm Period In-Track Position Difference and Distributions','Color',[0 0 0])

end