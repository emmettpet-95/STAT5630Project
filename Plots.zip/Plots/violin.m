function[h,MX,MED,bw_out]=violin(Y,varargin)
% Violin plot with weighted mean and weighted median for numeric arrays only
% Accepts n x m matrix Y and optional weights W

% Defaults
xL=[];
fc=[1 0.5 0];        % violin face color
lc='none';           % edge color
alp=0.5;             % transparency
mc='k';              % weighted mean line color
medc='r';            % weighted median line color
b=[];                % bandwidth
x=[];
W=[];                % weights

% Parse varargin
if any(strcmp(varargin,'facecolor')); fc = varargin{find(strcmp(varargin,'facecolor'))+1}; end
if any(strcmp(varargin,'edgecolor')); lc = varargin{find(strcmp(varargin,'edgecolor'))+1}; end
if any(strcmp(varargin,'facealpha')); alp = varargin{find(strcmp(varargin,'facealpha'))+1}; end
if any(strcmp(varargin,'mc')); mc = varargin{find(strcmp(varargin,'mc'))+1}; end
if any(strcmp(varargin,'medc')); medc = varargin{find(strcmp(varargin,'medc'))+1}; end
if any(strcmp(varargin,'bw')); b = varargin{find(strcmp(varargin,'bw'))+1}; end
if any(strcmp(varargin,'x')); x = varargin{find(strcmp(varargin,'x'))+1}; end
if any(strcmp(varargin,'weights')); W = varargin{find(strcmp(varargin,'weights'))+1}; end

% Expand face colors if needed
if size(fc,1)==1
    fc = repmat(fc,size(Y,2),1);
end

% Check weights
if ~isempty(W) && ~isequal(size(W), size(Y))
    error('Weights matrix must match size of Y.');
end

% X values
if isempty(x)
    x = 1:size(Y,2);
end

% Initialize outputs
MX = zeros(1,size(Y,2));
MED = zeros(1,size(Y,2));
bw_out = zeros(1,size(Y,2));
h = gobjects(1,size(Y,2));

% Compute density and statistics
for i = 1:size(Y,2)
    Yi = Y(:,i);
    Wi = [];
    if ~isempty(W)
        Wi = W(:,i);
    end

    % Kernel density
    if isempty(b)
        if isempty(Wi)
            [f,u,bb] = ksdensity(Yi);
        else
            [f,u,bb] = ksdensity(Yi,'Weights',Wi);
        end
    else
        if isempty(Wi)
            [f,u,bb] = ksdensity(Yi,'Bandwidth',b(i));
        else
            [f,u,bb] = ksdensity(Yi,'Bandwidth',b(i),'Weights',Wi);
        end
    end

    f = f/max(f)*0.3; % normalize width
    F(:,i) = f;
    U(:,i) = u;
    bw_out(i) = bb;

    % Weighted mean
    if isempty(Wi)
        MX(i) = mean(Yi);
    else
        Wi = Wi(:)/sum(Wi);
        MX(i) = sum(Yi.*Wi);
    end

    % Weighted median
    if isempty(Wi)
        MED(i) = median(Yi);
    else
        [Yi_sorted, idx] = sort(Yi);
        Wi_sorted = Wi(idx);
        cumw = cumsum(Wi_sorted);
        MED(i) = Yi_sorted(find(cumw >= 0.5,1));
    end
end

% Plot violins and lines
mean_lines = gobjects(1,size(Y,2));
median_lines = gobjects(1,size(Y,2));
for i = 1:size(Y,2)
    % Violin patch
    h(i) = fill([F(:,i)+x(i); flipud(x(i)-F(:,i))], [U(:,i); flipud(U(:,i))], fc(i,:), ...
        'FaceAlpha', alp, 'EdgeColor', lc);
    hold on;

    % Weighted mean line
    mean_lines(i) = plot([x(i)-max(F(:,i)) x(i)+max(F(:,i))],[MX(i) MX(i)], mc, 'LineWidth',2);

    % Weighted median line
    median_lines(i) = plot([x(i)-max(F(:,i)) x(i)+max(F(:,i))],[MED(i) MED(i)], medc, 'LineWidth',2,'LineStyle','--');
end

% Legend
h_violin = patch(NaN,NaN,fc(1,:),'FaceAlpha',alp,'EdgeColor',lc); % dummy violin for legend
L = legend([h_violin, mean_lines(1), median_lines(1)], {'Distribution','Weighted Mean','Weighted Median'});
set(L,'TextColor',[1 1 1],'Box','off','FontSize',12);


% Axis
axis([0.5 size(Y,2)+0.5 min(U(:)) max(U(:))]);
set(gca,'TickLength',[0 0],'FontSize',12)
box on
end