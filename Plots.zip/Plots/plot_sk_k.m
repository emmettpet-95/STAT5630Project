function plot_sk_k()

    load('Run1.mat'); load('Run2.mat');
    load('Run3.mat'); load('Run4.mat');

    load('a_dist.mat')
    n = size(Run1.X,3);
    normal_small = a_dist.normal_small(1:n);
    normal_large = a_dist.normal_large(1:n);
    skewed = a_dist.skewed(1:n);
    kurt = a_dist.kurt(1:n);

    tspan = Run1.tspan / 3600;

    dists = [normal_small, normal_large, skewed, kurt];
    Istats = {Run1.Istats, Run2.Istats, Run3.Istats, Run4.Istats};

    figure()
    
    names = {'Normal Small Variance','Normal Large Variance','Skewed','Heavy Tailed'};
    labels = {'Skewness','Kurtosis'};
    colors = {'g','b','r','m'};

    for i = 1:4
        figure(i+100);
        subplot(2,1,1)
        plot(tspan, ones(size(tspan)).*skewness(dists(:,i)), 'k')
        hold on
        plot(tspan, Istats{i}.skew, colors{i}, 'LineWidth',1.2)
        ylabel(labels{1})
        xticklabels([])
        subplot(2,1,2)
        plot(tspan, ones(size(tspan)).*kurtosis(dists(:,i)), 'k')
        hold on
        plot(tspan, Istats{i}.kurt, colors{i}, 'LineWidth',1.2)
        ylabel(labels{2})
        xlabel('Time [hr]')
        sgtitle(names{i})
        set(gcf,'Color',[1 1 1]);
    end
end