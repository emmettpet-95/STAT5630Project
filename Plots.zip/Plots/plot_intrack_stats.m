function plot_intrack_stats(saved_data_quiet, saved_data_storm, red_line_date, red_line_date2, orange)

figure()
t = tiledlayout(4,1,'TileSpacing','tight','Padding','compact'); % no vertical gaps

txt = {'Standard Deviation [km]','Skewness','Kurtosis','Mean [km]'};

% ---- 1st plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.mu_RIC(2,:)./1000, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.mu_RIC(2,:)./1000, 'b.')
ylabel(txt{4},"Fontsize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)','Location','southeast',"Fontsize",14)
xticks(0:1:36)
xticklabels([]) % no x labels here
grid on
ylim([0 10])
text(0.5, 8.8, 'a)', 'FontSize', 16, 'Color', 'r')

% ---- 1st plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.sd_RIC(2,:)./1000, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.sd_RIC(2,:)./1000, 'b.')
ylabel(txt{1},"Fontsize",14)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)','Location','southeast',"Fontsize",14)
xticks(0:1:36)
xticklabels([]) % no x labels here
grid on
ylim([0 1.2])
text(0.5, 1.05, 'b)', 'FontSize', 16, 'Color', 'r')

% ---- 2nd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.skew_RIC(2,:), 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.skew_RIC(2,:), 'b.')
ylabel(txt{2},"Fontsize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)','Location','southeast',"Fontsize",14)
xticklabels([])
xticks(0:1:36)
grid on
ylim([-1 1])
text(0.5, 0.75, 'c)', 'FontSize', 16, 'Color', 'r')

% ---- 3rd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.kurt_RIC(2,:), 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.kurt_RIC(2,:), 'b.')
ylabel(txt{3},"Fontsize",16)
xlabel('Elapsed Time [hr]',"Fontsize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)','Location','southeast',"Fontsize",14)
grid on
ylim([1 4])
text(0.5, 3.7, 'd)', 'FontSize', 16, 'Color', 'r')

% Format time axis every hour
xticks(0:1:36)

% Title + background
sgtitle('Quiet and Storm Period In-Track Position Difference Statistics',"Fontsize",20)
set(gcf,'Color',[1 1 1]);

end