function plot_density_stats(saved_data_quiet, saved_data_storm, red_line_date, red_line_date2, orange)

figure()
t = tiledlayout(4,1,'TileSpacing','tight','Padding','compact'); % no vertical gaps

txt = {'Standard Deviation [kg/m^3]','Skewness','Kurtosis','Mean [kg/m^3]'};

% ---- 1st plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.mu_rho, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.mu_rho, 'b.')
ylabel(txt{4},"FontSize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)',"FontSize",14)
xticks(0:1:36)
xticklabels([]) % no x labels here
grid on
ylim([0 5e-12])
text(0.5, 4.4e-12, 'a)', 'FontSize', 20, 'Color', 'r')

% ---- 1st plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.sd_rho, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.sd_rho, 'b.')
ylabel(txt{1},"FontSize",14)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)',"FontSize",14)
xticks(0:1:36)
xticklabels([]) % no x labels here
grid on
ylim([0 8e-13])
text(0.5, 6.9e-13, 'b)', 'FontSize', 20, 'Color', 'r')

% ---- 2nd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.skew_rho, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.skew_rho, 'b.')
ylabel(txt{2},"FontSize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)',"FontSize",14)
xticklabels([])
xticks(0:1:36)
grid on
ylim([-2 6])
text(0.5, 4.9, 'c)', 'FontSize', 20, 'Color', 'r')

% ---- 3rd plot ----
nexttile
set(gca,'Box','off','XAxisLocation','bottom')
plot(saved_data_quiet.t_hr, saved_data_quiet.kurt_rho, 'k.')
hold on
plot(saved_data_storm.t_hr, saved_data_storm.kurt_rho, 'b.')
ylabel(txt{3},"FontSize",16)
ylim([min(saved_data_storm.kurt_rho) 25])
xlabel('Elapsed Time [hr]',"FontSize",16)
xlim([0 36])
legend('Quiet (weighted)','Storm (weighted)',"FontSize",14)
grid on
ylim([-1 25])
text(0.5, 21.5, 'd)', 'FontSize', 20, 'Color', 'r')

% Format time axis every hour
xticks(0:1:36)

% Title + background
sgtitle('Quiet and Storm Period Density Statistics',"FontSize",20)
set(gcf,'Color',[1 1 1]);


end