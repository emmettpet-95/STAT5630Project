function plotOrbit3D(X)
% PLOTORBIT3D Plots a 3D orbit around Earth given state vectors
%
% Input:
%   X : Nx6 or 6x1 state vector [x y z vx vy vz] in km and km/s
%
% Example:
%   plotOrbit3D(X);

% Extract positions
if size(X,2) == 6
    r = X(:,1:3);
elseif size(X,1) == 6
    r = X(1:3,:)';
else
    error('X must be Nx6 or 6x1');
end

% Plot Earth
figure; hold on; grid on; axis equal;
[xs, ys, zs] = sphere(50);     % 50×50 mesh sphere
Re = 6371;                      % Earth radius in km
surf(Re*xs, Re*ys, Re*zs, 'FaceColor', 'c', 'EdgeColor', 'none');
alpha(0.3);                     % transparent Earth

% Plot orbit
plot3(r(:,1), r(:,2), r(:,3), 'r', 'LineWidth', 2);

% Labels and view
xlabel('X [km]');
ylabel('Y [km]');
zlabel('Z [km]');
title('3D Orbit Around Earth');
axis equal;
view(45,30);
camlight; lighting phong;

end