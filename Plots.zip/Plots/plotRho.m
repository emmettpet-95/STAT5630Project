function plotRho(tspan,rho)

figure;
hold on;
plot(tspan, rho)
xlabel('Time')
ylabel('Density [kg/m^3]')
title('Density Over Time')

end