function plot_a_dist(a_dist, n)
    
    normal_small = a_dist.normal_small(1:n);
    normal_large = a_dist.normal_large(1:n);
    skewed       = a_dist.skewed(1:n);
    kurt         = a_dist.kurt(1:n);

    % Combine all data to get global range
    all_data = [normal_small; normal_large; skewed; kurt];
    edges = linspace(min(all_data), max(all_data), 50);

    figure;

    color = {'g', 'b', 'r', 'm'};

    % --- Plot 1 ---
    subplot(2,2,1)
    histogram(normal_small, edges, 'FaceColor', color{1})
    title('Normal - Small Variance')
    xlabel('$\alpha$','Interpreter','latex'); ylabel('Count')
    add_stats(normal_small)

    % --- Plot 2 ---
    subplot(2,2,2)
    histogram(normal_large, edges, 'FaceColor', color{2})
    title('Normal - Large Variance')
    xlabel('$\alpha$','Interpreter','latex'); ylabel('Count')
    add_stats(normal_large)

    % --- Plot 3 ---
    subplot(2,2,3)
    histogram(skewed, edges, 'FaceColor', color{3})
    title('Skewed')
    xlabel('$\alpha$','Interpreter','latex'); ylabel('Count')
    add_stats(skewed)

    % --- Plot 4 ---
    subplot(2,2,4)
    histogram(kurt, edges, 'FaceColor', color{4})
    title('Heavy-Tailed (Kurtosis)')
    xlabel('$\alpha$','Interpreter','latex'); ylabel('Count')
    add_stats(kurt)

end

% --- Helper function for stats ---
function add_stats(x)
    mu = mean(x);
    sd = std(x);
    cv = sd/mu;
    sk = skewness(x);
    ku = kurtosis(x);

    txt = sprintf(['\\mu = %.2f\n',...
                   'CV = %.2f\n',...
                   'Sk = %.2f\n',...
                   'K = %.2f'], ...
                   mu, cv, sk, ku);

    % place text in top-right
    xlim_vals = xlim;
    ylim_vals = ylim;

    text(xlim_vals(2)-.1, ylim_vals(2)-2, txt, ...
        'HorizontalAlignment','right', ...
        'VerticalAlignment','top', ...
        'FontSize',8);
end