function saved_data = get_mu2(saved_data)

% Inputs:
%   w         : [100×p]
%   X_true    : [6×p×100]
%   RIC_error : [3×p×100]
%   rho       : [p×100]

    norm = sum(saved_data.w, 1);   % [1×p]
    norm_inter = sum(saved_data.w_inter, 1);

    % mu_X
    X_perm = permute(saved_data.X_true, [3,2,1]);       % [100×p×6]
    weighted_X = X_perm .* saved_data.w_inter;                % implicit expansion: [100×p×6]
    mu_X = squeeze(sum(weighted_X,1)) ./ norm_inter';  % [p×6]
    saved_data.mu_X = mu_X';                                % [6×p]

    % mu_RIC
    RIC_perm = permute(saved_data.RIC_error, [3,2,1]);  % [100×p×3]
    weighted_RIC = RIC_perm .* saved_data.w_inter;
    mu_RIC = squeeze(sum(weighted_RIC,1)) ./ norm_inter';
    saved_data.mu_RIC = mu_RIC';                            % [3×p]

    % mu_rho
    rho_T = saved_data.rho';  % [100×p]
    weighted_rho = nansum(saved_data.w .* rho_T, 1);  % ignores NaNs in rho_T
    norm_nonan = nansum(saved_data.w .* ~isnan(rho_T), 1); % adjust norm to count only where rho_T isn’t NaN
    saved_data.mu_rho = weighted_rho ./ norm_nonan;
    % weighted_rho = sum(w .* rho_T, 1);  % [1×p]
    % mu_rho = weighted_rho ./ norm;      % [1×p]

    % mu_kp
    kp = saved_data.kp; % [100 x p]
    weighted_kp = (saved_data.w .* kp);
    mu_kp = sum(weighted_kp,1) ./ norm;
    saved_data.mu_kp = mu_kp;

    % % Plot
    % figure;
    % sgtitle('Weighted Avgs')
    % 
    % % Subplot 1: mu_X
    % subplot(5,1,1);
    % plot(saved_data.mu_X');  
    % title('X');
    % legend('Dim 1','Dim 2','Dim 3','Dim 4','Dim 5','Dim 6', 'Location','best');
    % 
    % % Subplot 2: mu_R
    % subplot(5,1,2);
    % plot(saved_data.mu_RIC(1,:));
    % title('R');
    % 
    % % Subplot 3: mu_I
    % subplot(5,1,3);
    % plot(saved_data.mu_RIC(2,:));
    % title('I');
    % 
    % % Subplot 4: mu_C
    % subplot(5,1,4);
    % plot(saved_data.mu_RIC(3,:));
    % title('C');
    % 
    % % Subplot 5: mu_rho
    % subplot(5,1,5);
    % plot(saved_data.mu_rho);
    % title('rho');

end
