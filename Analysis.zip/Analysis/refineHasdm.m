function [Rho_out, LatGrid, LonGrid, AltGrid, time_out] = refineHasdm(A_short, lat_step, lon_step, alt_step, time_step)
% REFINEHASDMTIME Refine HASDM density grid spatially and temporally
%
% Inputs:
%   A_short   - Nx7 HASDM array [time, JD, HTM, lat, lon, LST, rho]
%   lat_step  - latitude step [deg]
%   lon_step  - longitude step [deg]
%   alt_step  - altitude step [km]
%   time_step - time step [minutes] for output grid
%
% Outputs:
%   Rho_out   - interpolated density [lat x lon x alt x time]
%   LatGrid   - latitude grid [deg]
%   LonGrid   - longitude grid [deg]
%   AltGrid   - altitude grid [km]
%   time_out  - datetime vector for output time steps

% Convert HASDM times to datetime
time_vec = datetime(string(A_short(:,1)), 'InputFormat','yyyyMMddHH');

% Define output time vector
time_out = (time_vec(1):minutes(time_step):time_vec(end))';

% Spatial grid
lat_vec = min(A_short(:,4)):lat_step:max(A_short(:,4));
lon_vec = min(A_short(:,5)):lon_step:max(A_short(:,5));
alt_vec = min(A_short(:,3)):alt_step:max(A_short(:,3));
[LatGrid, LonGrid, AltGrid] = ndgrid(lat_vec, lon_vec, alt_vec);

% Pre-allocate output
Rho_out = zeros(length(lat_vec), length(lon_vec), length(alt_vec), length(time_out));

% Unique original times
times_unique = unique(time_vec);

% Spatial interpolation for each original time
Rho_grid_orig = zeros(length(lat_vec), length(lon_vec), length(alt_vec), length(times_unique));
for k = 1:length(times_unique)
    t = times_unique(k);
    idx = (time_vec == t);
    
    X = A_short(idx,4);  % lat
    Y = A_short(idx,5);  % lon
    Z = A_short(idx,3);  % alt
    Rho = A_short(idx,7);
    
    % Log-linear interpolation in space
    F = scatteredInterpolant(X,Y,Z,log(Rho),'linear','nearest');
    Rho_grid_orig(:,:,:,k) = exp(F(LatGrid,LonGrid,AltGrid));
end

% Time interpolation for each spatial point
for i = 1:length(lat_vec)
    for j = 1:length(lon_vec)
        for k = 1:length(alt_vec)
            % Extract density over original times for this spatial point
            rho_time = squeeze(Rho_grid_orig(i,j,k,:));
            
            % Interpolate to desired time step
            Rho_out(i,j,k,:) = interp1(datenum(times_unique), rho_time, datenum(time_out), 'linear', 'extrap');
        end
    end
end

end