function [saved_data, n, p, E] = get_data(dataset_num)

    folder = 'Saved Data';
    filename = sprintf('saved_data%d.mat', dataset_num);
    filepath = fullfile(folder, filename);
    
    if isfile(filepath)
        load(filepath);
    else
        error("File %s does not exist.", filepath);
    end
    
    % t_hr = saved_data.t_hr; 
    % datetime_values = saved_data.tspan; 
    saved_data.jd_values = juliandate(saved_data.tspan);
    % X_true = saved_data.X_true;
    % rho = saved_data.rho; 
    saved_data.rho(1,:) = saved_data.rho(2,:);
    % X_ND = saved_data.X_ND;
    n = size(saved_data.X_true,1);
    p = size(saved_data.X_true,2);
    E = size(saved_data.X_true,3)-1;

    % RIC errors
    RIC_error = zeros(3,p,E+1);
    for i = 1:(E+1)
        for k = 1:p
            R_ECI2RIC = rotateECI2RIC(saved_data.X_ND(1:3,k), saved_data.X_ND(4:6,k));
            X_ND_ric = R_ECI2RIC*saved_data.X_ND(1:3,k);
            X_true_ric = R_ECI2RIC*saved_data.X_true(1:3,k,i);
            RIC_error(:,k,i) = (X_true_ric - X_ND_ric)*1000; %km to m
            % RIC_error(:,k) = abs(RIC_error(:,k)); 
        end
    end
    saved_data.UW_RIC_error = RIC_error(:,:,1);
    saved_data.RIC_error = RIC_error(:,:,2:end);

    % Drag Orbits
    saved_data.UW_X_true = saved_data.X_true(:,:,1);
    saved_data.X_true = saved_data.X_true(:,:,2:end);

    % Density
    if size(saved_data.rho,1) ~= p
        saved_data.rho = [saved_data.rho; saved_data.rho(end,:)];
    end
    saved_data.UW_rho = saved_data.rho(:,1)';
    saved_data.rho = saved_data.rho(:,2:end);

end
