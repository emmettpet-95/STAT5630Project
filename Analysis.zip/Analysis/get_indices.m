function [saved_data, kp_web, f107_web, red_line_date] = get_indices(saved_data, p)
    
    % Weights kp and w and Ap    
    % w = saved_data.w;
    % Ap, Kp, f10.7 from NC files
    % kp = saved_data.kp;
    % f107 = saved_data.f107;
    %saved_data.ap = convert_ApKp(saved_data.kp,'Kp');
            
    if size(saved_data.w,2) ~= length(saved_data.tspan)
        saved_data.w = [saved_data.w, saved_data.w(:,end)];
    end
    %if size(saved_data.ap,2) ~= length(saved_data.tspan)
     %   saved_data.ap = [saved_data.ap, saved_data.ap(:,end)];
    %end
    if size(saved_data.kp,2) ~= length(saved_data.tspan)
        saved_data.kp = [saved_data.kp, saved_data.kp(:,end)];
    end
    if size(saved_data.f107,2) ~= length(saved_data.tspan)
        saved_data.f107 = [saved_data.f107, saved_data.f107(:,end)];
    end

    % Time integrated weights
    w_inter = nan(size(saved_data.w));
        
    for k = 1:p
        w_k = sum(saved_data.w(:,1:k),2);
        w_inter(:,k) = w_k ./ sum(w_k,1);
    end
    saved_data.w_inter = w_inter;
       
    % Kp and f10.7 from online
    [kp_web, f107_web, ~, red_line_date] = get_F107kp(saved_data.tspan);
    % ap_web = convert_ApKp(kp_web,'Kp');
end