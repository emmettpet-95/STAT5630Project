function saved_data = get_sd2(n, p, saved_data)

    sigma_X = zeros(n,p);
    sigma_RIC = zeros(3,p);
    for i = 1:p
        sigma_X(:,i) = sqrt(diag(saved_data.cov_X(:,:,i)));
        sigma_RIC(:,i) = sqrt(diag(saved_data.cov_RIC(:,:,i)));
    end
    saved_data.sd_X = sigma_X;
    saved_data.sd_RIC = sigma_RIC;

    % Preallocate
    sigma_kp = zeros(p,1);
    % sigma_ap = zeros(p,1);
    sigma_f107 = zeros(p,1);
    sigma_rho = zeros(p,1);

    UW_sigma_kp = zeros(p,1);
    % UW_sigma_ap = zeros(p,1);
    UW_sigma_f107 = zeros(p,1);
    UW_sigma_rho = zeros(p,1);
    UW_sigma_RIC = zeros(3,p);

    % Transpose rho to [ensemble × time]
    rho = saved_data.rho';

    % Loop over time steps
    for k = 1:p
        % Extract and normalize weights (1×100)
        wk = saved_data.w(:,k)';
        wk = wk / sum(wk);

        % Helper: compute weighted std
        sigma_kp(k)   = weighted_std(saved_data.kp(:,k),   wk);
        % sigma_ap(k)   = weighted_std(saved_data.ap(:,k),   wk);
        sigma_f107(k) = weighted_std(saved_data.f107(:,k), wk);
        sigma_rho(k)  = weighted_std(rho(:,k),  wk);

        UW_sigma_kp(k)   = std(saved_data.kp(:,k), 0);
        % UW_sigma_ap(k)   = std(saved_data.ap(:,k), 0);
        UW_sigma_f107(k) = std(saved_data.f107(:,k), 0);
        UW_sigma_rho(k)  = std(rho(:,k), 0);

        % Unweighted std for RIC (3×E ensemble at time k)
        RIC_k = squeeze(saved_data.RIC_error(:,k,:)); % 3×E
        for i = 1:3
            UW_sigma_RIC(i,k) = std(RIC_k(i,:), 0);
        end

    end
    
    saved_data.sd_kp = sigma_kp;
    % saved_data.sd_ap = sigma_ap;
    saved_data.sd_f107 = sigma_f107;
    saved_data.sd_rho = sigma_rho;

    saved_data.UW_sd_kp   = UW_sigma_kp;
    % saved_data.UW_sd_ap   = UW_sigma_ap;
    saved_data.UW_sd_f107 = UW_sigma_f107;
    saved_data.UW_sd_rho  = UW_sigma_rho;
    saved_data.UW_sd_RIC = UW_sigma_RIC;

end

function s = weighted_std(x, w)
    % x: [100×1], w: [1×100]
    mu = sum(w .* x');
    var = sum(w .* (x' - mu).^2);
    s = sqrt(var);
end
