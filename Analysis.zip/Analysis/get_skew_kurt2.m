function saved_data = get_skew_kurt2(n, p, saved_data)
    
    skew_X = zeros(n,p);
    kurt_X = zeros(n,p);
    skew_RIC = zeros(3,p);
    kurt_RIC = zeros(3,p);
    skew_rho = zeros(1,p);
    kurt_rho = zeros(1,p);

    UW_skew_X   = zeros(n,p);
    UW_kurt_X   = zeros(n,p);
    UW_skew_RIC = zeros(3,p);
    UW_kurt_RIC = zeros(3,p);
    UW_skew_rho = zeros(1,p);
    UW_kurt_rho = zeros(1,p);

    for k = 1:p
        % weights_k: 1×E
        weights_k = saved_data.w(:,k)';
        weights_k = weights_k / sum(weights_k);

        wk_inter = saved_data.w_inter(:,k)';
        wk_inter = wk_inter / sum(wk_inter);

        % Extract centered & normalized samples
        x_k = squeeze(saved_data.X_true(:,k,:));         % n×E
        RIC_k = squeeze(saved_data.RIC_error(:,k,:));    % 3×E
        rho_k = saved_data.rho(k,:); % 1xE

        centered_x = x_k - saved_data.mu_X(:,k);          % n×E
        centered_RIC = RIC_k - saved_data.mu_RIC(:,k);    % 3×E
        centered_rho = rho_k - saved_data.mu_rho(:,k);    % 1xE

        z_x = centered_x ./ saved_data.sd_X(:,k);       % n×E
        z_RIC = centered_RIC ./ saved_data.sd_RIC(:,k); % 3×E
        z_rho = centered_rho ./ saved_data.sd_rho(k);  % 1xE

        % Compute weighted moments
        skew_X(:,k)  = sum(z_x.^3 .* wk_inter, 2);
        kurt_X(:,k)  = sum(z_x.^4 .* wk_inter, 2);
        skew_RIC(:,k)  = sum(z_RIC.^3 .* wk_inter, 2);
        kurt_RIC(:,k)  = sum(z_RIC.^4 .* wk_inter, 2);
        skew_rho(:,k) = sum(z_rho.^3 .* weights_k, 2);
        kurt_rho(:,k) = sum(z_rho.^4 .* weights_k, 2);

        % ----- Unweighted skewness & kurtosis -----
        for i = 1:n
            UW_skew_X(i,k) = skewness(x_k(i,:), 0);  % sample version
            UW_kurt_X(i,k) = kurtosis(x_k(i,:), 0);
        end
        for i = 1:3
            UW_skew_RIC(i,k) = skewness(RIC_k(i,:), 0);
            UW_kurt_RIC(i,k) = kurtosis(RIC_k(i,:), 0);
        end
        UW_skew_rho(:,k) = skewness(rho_k, 0);
        UW_kurt_rho(:,k) = kurtosis(rho_k, 0);

    end
    
    saved_data.skew_X = skew_X;
    saved_data.kurt_X = kurt_X;
    saved_data.skew_RIC = skew_RIC;
    saved_data.kurt_RIC = kurt_RIC;
    saved_data.skew_rho = skew_rho;
    saved_data.kurt_rho = kurt_rho;

    saved_data.UW_skew_X   = UW_skew_X;
    saved_data.UW_kurt_X   = UW_kurt_X;
    saved_data.UW_skew_RIC = UW_skew_RIC;
    saved_data.UW_kurt_RIC = UW_kurt_RIC;
    saved_data.UW_skew_rho = UW_skew_rho;
    saved_data.UW_kurt_rho = UW_kurt_rho;

end
