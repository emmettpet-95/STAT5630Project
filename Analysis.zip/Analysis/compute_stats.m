function stats = compute_stats(X)
% X = 1x577x200 = 1xNxC

% Force shape [N x C]
X = reshape(X, size(X,2), size(X,3));

N = size(X,1);

mu   = nan(N,1);
sd   = nan(N,1);
sk   = nan(N,1);
kurt = nan(N,1);

for i = 1:N
    
    xi = X(i,:);           % samples at time i
    xi = xi(~isnan(xi));   % remove NaNs
    
    if isempty(xi)
        continue
    end
    
    mu(i) = mean(xi);
    
    if numel(xi) > 1
        sd(i) = std(xi,0);
        sk(i) = skewness(xi);
        kurt(i) = kurtosis(xi);
    end
    
end

% Output as row vectors
stats.mu   = mu.';
stats.sd   = sd.';
stats.skew = sk.';
stats.kurt = kurt.';

end