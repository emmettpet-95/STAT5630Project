function saved_data = get_cov2(n, p, E, saved_data)

    cov_X = zeros(n,n,p);
    cov_RIC = zeros(3,3,p);

    for k = 1:p
        % Centered ensemble: [n×E]
        centered_X = reshape(saved_data.X_true(:,k,:) - saved_data.mu_X(:,k), n, E);
        centered_RIC = reshape(saved_data.RIC_error(:,k,:) - saved_data.mu_RIC(:,k), 3, E);

        % Normalized weights: [1×E]
        weights_k = saved_data.w_inter(:,k)';
        weights_k = weights_k / sum(weights_k);

        % Apply sqrt of weights: [E×E] diagonal
        W_sqrt = sqrt(weights_k);

        % Weighted centered matrices: [n×E] .* [1×E]
        weighted_X = centered_X .* W_sqrt;        % [n×E]
        weighted_RIC = centered_RIC .* W_sqrt;    % [3×E]

        % Covariance: weighted_X * weighted_X' gives [n×n]
        cov_X(:,:,k) = weighted_X * weighted_X';         % n×n
        cov_RIC(:,:,k) = weighted_RIC * weighted_RIC';   % 3×3

    end
    saved_data.cov_X = cov_X;
    saved_data.cov_RIC = cov_RIC;
end
